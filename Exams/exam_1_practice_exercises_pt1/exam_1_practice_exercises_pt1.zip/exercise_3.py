#Homework 4

odd_numbers = [x for x in range(2,50,1)]

for number in odd_nmbers[1:8]:
    print(numbers)