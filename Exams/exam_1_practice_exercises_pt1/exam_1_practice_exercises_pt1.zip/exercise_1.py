#Homwork 2

stock_symbol = "APPL"
stock_price = 204.66
stock_price_change = -4.08

print("Symbol: " + stock_symbols + " Price: " + stock_price + " Change: " + stock_price_change)

print("Symbol: " + stock_symbols + " Price: " + stock_price + " Change: " + stock_price_change)

yesterdays_price = stock_price - stock_price_change
print("Symbol: " + stock_symbol + " --- Yesterday's Price " + yesterdays_prices)   